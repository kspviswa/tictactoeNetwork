#include "game2.h"
#include "ui_game2.h"
#include <QMessageBox>

//QTimer *timer;
Game2::Game2(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Game2)
{
    ui->setupUi(this);

    //Hide User credentials
    ui->text_UserName->hide();
    ui->label_Username->hide();
    ui->text_ServerIP->hide();
    ui->label_ServerIP->hide();

    Local_Participant.clear();
    Remote_Participant.clear();
    generic_Symbol = "Z";
    ServerIP.clear();
    pPrevButtonMarked = NULL;

    setButtonState(false);

    timer = new QTimer(this);

    connect(timer, SIGNAL(timeout()), this, SLOT(update()));

    //timer = new QTimer(this);
    //connect(timer, SIGNAL(timeout()), this, SLOT(update(QPushButton *pPushButton_temp)));

    QMainWindow::show();
}

void Game2::update()
{
    //QPushButton *pPushButton_temp;
    QMessageBox msgBox;
    msgBox.setText("Timer Expired - " + Local_Participant.toHtmlEscaped() + " Won");
    msgBox.exec();
    //pPushButton_temp->setDisabled(true);
    //pPushButton_temp->setText("X");
    //ui->Button_Submit->click();
}

Game2::~Game2()
{
    delete ui;
}

bool Game2::Registration()
{
    QString myUserName = ui->text_UserName->toPlainText();
    if (myUserName == "")
    {
        QMessageBox msgBox;
        msgBox.setText("Enter Username");
        msgBox.exec();
        ui->text_UserName->setFocus();
        return false;
    }
    QString myIdentity = myUserName;
    ui->list_Participants->addItem(myIdentity);
    Local_Participant.append(myIdentity);
    ui->text_UserName->hide();
    ui->label_Username->hide();
    ui->text_ServerIP->hide();
    ui->label_ServerIP->hide();
    ui->label_LocalPlayerName->setText("Player Name: " + ui->text_UserName->toPlainText());
    ServerIP = ui->text_ServerIP->toPlainText();

    // Register structure contents
    memset(&stUserData,0,sizeof(stUserData));

    memcpy(stUserData.lplayerName,Local_Participant.toStdString().c_str(),Local_Participant.size());
    memcpy(stUserData.ServerIP,ServerIP.toStdString().c_str(),ServerIP.size());

    ui->Button_Submit->setEnabled(false);

    // Game Logic starts
    if (!RegisterPlayer(&stUserData))
    {
        QMessageBox msgBox;
        msgBox.setText("Registration failed.. Possible Reasons: Username already exist or Communication failure. Try to Re-register");
        msgBox.exec();
        return false;
    }

    return true;
}

void Game2::on_Button_Submit_clicked()
{
    if(ui->Button_Submit->text()=="Start")
    {
        // Enable all User credentials input route.
        ui->text_UserName->show();
        ui->label_Username->show();
        ui->text_ServerIP->show();
        ui->label_ServerIP->show();

        ui->text_UserName->setFocus();
        ui->Button_Submit->setText("Register");
    }
    else if (ui->Button_Submit->text()=="Register")
    {
        if ( Registration() )
        {
            ui->Button_Submit->setText("Submit");
            //ui->Button_Submit->setText("Play");
        }
        else
        {
            ui->Button_Submit->setText("Register");
        }
    }
    /*else if (ui->Button_Submit->text()=="Play")
    {
        setButtonState(true);
        ui->Button_Submit->setText("Submit");
    }*/
    else
    {
        // Catch the PushButton Contents and send to Lower Layers.
        if (pPrevButtonMarked->text() == "")
        {
            QMessageBox msgBox;
            msgBox.setText("No update in Board. Please choose at least one box");
            msgBox.exec();
            return;
        }
        ui->Button_Submit->setEnabled(false);

        pPrevButtonMarked = NULL;
        string szBoardInfo;
        getBoardInfo(szBoardInfo);
        QString BoardDetails = szBoardInfo.c_str();

        //timer->start(5000);

        /*QMessageBox msgBox;
        msgBox.setText("Board Contents " + BoardDetails.toHtmlEscaped());
        msgBox.exec();*/

        //QTimer::singleShot(5000, this, SLOT(update()));

        // szPreviousState = szBoardInfo;
        memset(RemoteState,0,sizeof(RemoteState));

        // Start the timer
        timer->start(10000);

        memcpy(stUserData.lplayerName,Local_Participant.toStdString().c_str(),Local_Participant.size());

        // Push data to Lower layers
        SendMove(stUserData);

        // Disable the submit once submitted the board contents.
        ui->Button_Submit->setEnabled(false);

        // Update the Previous State
        //szPreviousState = BoardDetails.toStdString();
        //QTimer::singleShot(5000, this, SLOT(update()));

        //gui_update_board(stUserData);
    }
}

void Game2::setButtonState(bool bState)
{
    ui->pushButton->setEnabled(bState);      ui->pushButton_2->setEnabled(bState);
    ui->pushButton_3->setEnabled(bState);    ui->pushButton_4->setEnabled(bState);
    ui->pushButton_5->setEnabled(bState);    ui->pushButton_6->setEnabled(bState);
    ui->pushButton_7->setEnabled(bState);    ui->pushButton_8->setEnabled(bState);
    ui->pushButton_9->setEnabled(bState);
}

void Game2::getBoardInfo(string & szBoardInfo)
{
    szBoardInfo =   getButtonStatus(ui->pushButton)   + getButtonStatus(ui->pushButton_2) +
                    getButtonStatus(ui->pushButton_3) + getButtonStatus(ui->pushButton_4) +
                    getButtonStatus(ui->pushButton_5) + getButtonStatus(ui->pushButton_6) +
                    getButtonStatus(ui->pushButton_7) + getButtonStatus(ui->pushButton_8) +
                    getButtonStatus(ui->pushButton_9);

}



void Game2::on_Button_EndGame_clicked()
{
    QMessageBox msgBox;
    msgBox.setText("Player opted for Closing the game. ");
    msgBox.setInformativeText("Do you want to save your changes?");
    msgBox.setStandardButtons(QMessageBox::Ok | QMessageBox::Cancel);
    msgBox.setDefaultButton(QMessageBox::Ok);
    msgBox.exec();

    QMainWindow::close();
}



void Game2::gui_update_data(tUserData stUserData)
{
    /*Remote_Participant = "Kumar";
    memcpy(stUserData.rplayerName,Remote_Participant.toStdString().c_str(),Remote_Participant.size());
    memcpy(&stUserData.lFlag,"X",strlen("X"));
    memcpy(&stUserData.rFlag,"O",strlen("O"));*/



    timer->stop();

    QString szSymbol_l(stUserData.lFlag);
    ui->text_LocalSymbol->setText(szSymbol_l);
    QString szSymbol_r(stUserData.rFlag);
    ui->text_RemoteSymbol->setText(szSymbol_r);
    Remote_Participant.append(stUserData.rplayerName);
    ui->list_Participants->addItem(Remote_Participant);

    if (Remote_Participant.isEmpty())
    {
        return ;
    }
    ui->Button_Submit->setEnabled(true);
    setButtonState(true);
//
}

void Game2::gui_update_board(tUserData stUserData)
{

    /*char *pszChar = pszBoardContents;

    QMessageBox msgBox;
    msgBox.setText(pszChar);
    msgBox.exec();*/

    memcpy(RemoteState,stUserData.game_state,sizeof(stUserData.game_state));

    int i=0;

    isNUll(i,ui->pushButton);      i++;
    isNUll(i,ui->pushButton_2);    i++;
    isNUll(i,ui->pushButton_3);    i++;
    isNUll(i,ui->pushButton_4);    i++;
    isNUll(i,ui->pushButton_5);    i++;
    isNUll(i,ui->pushButton_6);    i++;
    isNUll(i,ui->pushButton_7);    i++;
    isNUll(i,ui->pushButton_8);    i++;
    isNUll(i,ui->pushButton_9);

    string szLocalBoardInfo;
    getBoardInfo(szLocalBoardInfo);

    int nLocalSymbol = 0;
    int nRemoteSymbol = 0;
    for (int i=0; i<szLocalBoardInfo.length();i++)
    {
        if (szLocalBoardInfo.at(i) == Local_Symbol.at(0))
        {
            nLocalSymbol++;
        }
        else if (szLocalBoardInfo.at(i) == Remote_Symbol.at(0))
        {
            nRemoteSymbol++;
        }
        else
        {
            // Do nothing.
        }
    }

    if ((nLocalSymbol < nRemoteSymbol) || ((nLocalSymbol == nRemoteSymbol) && (Local_Symbol == "O")))
    {
        ui->Button_Submit->setEnabled(true);
    }
    else
    {
        ui->Button_Submit->setEnabled(false);
    }

}


/* Button Press Event Handlers */

void Game2::on_pushButton_clicked()
{
    Button_clicked(ui->pushButton);
}

void Game2::on_pushButton_2_clicked()
{
    Button_clicked(ui->pushButton_2);
}

void Game2::on_pushButton_3_clicked()
{
    Button_clicked(ui->pushButton_3);
}

void Game2::on_pushButton_4_clicked()
{
    Button_clicked(ui->pushButton_4);
}

void Game2::on_pushButton_5_clicked()
{
    Button_clicked(ui->pushButton_5);
}

void Game2::on_pushButton_6_clicked()
{
    Button_clicked(ui->pushButton_6);
}

void Game2::on_pushButton_7_clicked()
{
    Button_clicked(ui->pushButton_7);
}

void Game2::on_pushButton_8_clicked()
{
    Button_clicked(ui->pushButton_8);
}

void Game2::on_pushButton_9_clicked()
{
    Button_clicked(ui->pushButton_9);
}


/* Utilities */

void Game2::Button_clicked(QPushButton *pPushButton)
{
    QString QszMarked(stUserData.lFlag);
    pPushButton->setText(QszMarked);
    checkDuplicate();
    pPrevButtonMarked=pPushButton;
}

void Game2::isNUll(int pos, QPushButton * rPushButton)
{
    QString QszFinal;

    char *szEmpty = "Z";
    if (RemoteState[pos]!=szEmpty[0])
    {
        QszFinal.append(RemoteState[pos]);
        rPushButton->setEnabled(false);
    }
    else
    {
        QszFinal.append("");
    }
    rPushButton->setText(QszFinal);
}

string Game2::getButtonStatus(QPushButton *pPushButton_temp)
{
    if (pPushButton_temp->text() == "X")
    {
        return "X";
    }
    else if (pPushButton_temp->text() == "O")
    {
        return "O";
    }
    else
    {
        return "Z";
    }
}

void Game2::checkDuplicate()
{
    if(pPrevButtonMarked != NULL)
    {
        pPrevButtonMarked->setText("");
    }
}
