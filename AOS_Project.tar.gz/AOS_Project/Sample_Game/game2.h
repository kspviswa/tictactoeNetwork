#ifndef GAME2_H
#define GAME2_H

#include <QMainWindow>
#include <string.h>
#include <QPushButton>
#include <QTimer>
#include <client/headers.h>

using namespace std;

namespace Ui {
class Game2;
}

/*typedef struct user_data
{
    char game_state[9];
    char lFlag;
    char rFlag;
    char lplayerName[10];
    char rplayerName[10];
    char ServerIP[16];
}tUserData;
*/

class Game2 : public QMainWindow
{
    Q_OBJECT

public:
    explicit Game2(QWidget *parent = 0);
    ~Game2();
    void gui_update_board(tUserData stUserData);
    void gui_update_data(tUserData stUserData);
    void show_popup();

private slots:

    void on_Button_Submit_clicked();

    void on_Button_EndGame_clicked();

    void update();

    bool Registration();

    string getButtonStatus(QPushButton *pPushButton_temp);

    void getBoardInfo(string & szBoardInfo);


    /* Button Click Event Handlers */

    void on_pushButton_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_pushButton_4_clicked();
    void on_pushButton_5_clicked();
    void on_pushButton_6_clicked();
    void on_pushButton_7_clicked();
    void on_pushButton_8_clicked();
    void on_pushButton_9_clicked();

    /* Utility functions */
    void Button_clicked(QPushButton *pPushButton);
    void checkDuplicate();
    void isNUll(int pos, QPushButton * rPushButton);
    void setButtonState(bool bState);

private:
    Ui::Game2 *ui;
    QString Local_Participant;
    QString ServerIP;
    QString LocalIP;
    QString Remote_Participant;
    string Local_Symbol;
    string Remote_Symbol;
    string generic_Symbol;
    string szPreviousState;
    char RemoteState[20];
    tUserData stUserData;
    QPushButton * pPrevButtonMarked;
    QTimer *timer;
};

#endif // GAME2_H
