#ifndef COMMON_H
#define COMMON_H

#include <game2.h>
using namespace Ui;
extern Ui::Game2 * Game_Ref;
#endif // COMMON_H
