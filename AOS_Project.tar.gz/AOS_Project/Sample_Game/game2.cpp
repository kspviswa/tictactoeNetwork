#include "game2.h"
#include "ui_game2.h"
#include <QMessageBox>
//#include "Common.h"

//Game2 *Game_Ref;

//QTimer *timer;
Game2::Game2(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Game2)
{
    ui->setupUi(this);

    //Hide User credentials
    /*ui->text_UserName->hide();
    ui->label_Username->hide();
    ui->text_ServerIP->hide();
    ui->label_ServerIP->hide();
    ui->text_LocalIP->hide();
    ui->label_LocalIP->hide();*/
    ui->groupBox_Registration->setVisible(false);

    Local_Participant.clear();
    Remote_Participant.clear();
    generic_Symbol = "Z";
    ServerIP.clear();
    LocalIP.clear();
    pPrevButtonMarked = NULL;

    ui->text_LocalSymbol->setAlignment(Qt::AlignCenter);
    ui->text_RemoteSymbol->setAlignment(Qt::AlignCenter);

    setButtonState(false);
    Game2_Pointer();

    //timer = new QTimer(this);
    timer_Clock = new QTimer(this);
    timer_Regular = new QTimer(this);

    //connect(timer, SIGNAL(timeout()), this, SLOT(update()));
    connect(timer_Clock, SIGNAL(timeout()), this, SLOT(showTime()));
    connect(timer_Regular,SIGNAL(timeout()),this, SLOT(gui_update()));

    //timer = new QTimer(this);
    //connect(timer, SIGNAL(timeout()), this, SLOT(update(QPushButton *pPushButton_temp)));

    QMainWindow::show();
}

void Game2::update(QString szResult)
{
    //QPushButton *pPushButton_temp;
    QMessageBox msgBox;
    msgBox.setText(szResult);
    msgBox.exec();
    //pPushButton_temp->setDisabled(true);
    //pPushButton_temp->setText("X");
    //ui->Button_Submit->click();
}

Game2::~Game2()
{
    delete ui;
}

bool Game2::Registration()
{
    QString myUserName = ui->text_UserName->toPlainText();
    if (myUserName == "")
    {
        QMessageBox msgBox;
        msgBox.setText("Enter Username");
        msgBox.exec();
        ui->text_UserName->setFocus();
        return false;
    }
    QString myIdentity = myUserName;
    ui->list_Participants->addItem(myIdentity);
    Local_Participant.append(myIdentity);

    ui->groupBox_Registration->setVisible(false);

    /*ui->text_UserName->hide();
    ui->label_Username->hide();
    ui->text_ServerIP->hide();
    ui->label_ServerIP->hide();
    ui->text_LocalIP->hide();
    ui->label_LocalIP->hide();*/

    ui->label_LocalPlayerName->setText("Player Name: " + ui->text_UserName->toPlainText());
    ServerIP = ui->text_ServerIP->toPlainText();
    LocalIP = ui->text_LocalIP->toPlainText();

    // Register structure contents
    memset(&stUserData,0,sizeof(stUserData));
    memcpy(stUserData.lplayerName,Local_Participant.toStdString().c_str(),Local_Participant.size());
    memcpy(stUserData.ServerIP,ServerIP.toStdString().c_str(),ServerIP.size());
    memcpy(stUserData.LocalIP,LocalIP.toStdString().c_str(),LocalIP.size());

    ui->Button_Submit->setEnabled(false);

    // Game Logic starts
    if (RegisterPlayer(&stUserData))
    {
        QMessageBox msgBox;
        msgBox.setText("Registration failed.. Possible Reasons: Username already exist or Communication failure. Try to Re-register");
        msgBox.exec();
        ui->groupBox_Registration->setVisible(true);
        ui->groupBox_Credentials->setVisible(false);
        return false;
    }

    ui->groupBox_Credentials->setVisible(true);

    timer_Regular->start(1000);

    /*Remote_Participant = "Kumar";
    //memcpy(stUserData.rplayerName,Remote_Participant.toStdString().c_str(),Remote_Participant.size());
    memcpy(&stUserData.lFlag,"X",strlen("X"));
    memcpy(&stUserData.rFlag,"O",strlen("O"));

    gui_update_data (stUserData);*/

    return true;
}

void Game2::on_Button_Submit_clicked()
{
    if(ui->Button_Submit->text()=="Start")
    {
        // Enable all User credentials input route.
        ui->groupBox_Credentials->setVisible(false);
        ui->groupBox_Registration->setVisible(true);

        /*ui->text_UserName->show();
        ui->label_Username->show();
        ui->text_ServerIP->show();
        ui->label_ServerIP->show();
        ui->text_LocalIP->show();
        ui->label_LocalIP->show();*/

        ui->text_UserName->setFocus();
        ui->Button_Submit->setText("Register");
    }
    else if (ui->Button_Submit->text()=="Register")
    {
        if ( Registration() )
        {
            ui->Button_Submit->setText("Submit");
            setButtonState(true); // Remove After testing
        }
        else
        {
            ui->Button_Submit->setText("Register");
        }
    }
    else
    {
        // Catch the PushButton Contents and send to Lower Layers.
        if (pPrevButtonMarked == NULL)
        {
            QMessageBox msgBox;
            msgBox.setText("No update in Board. Please choose at least one box");
            msgBox.exec();
            return;
        }
        ui->Button_Submit->setEnabled(false);

        pPrevButtonMarked = NULL;
        string szBoardInfo;
        getBoardInfo(szBoardInfo);
        QString BoardDetails = szBoardInfo.c_str();

        // szPreviousState = szBoardInfo;
        memset(RemoteState,0,sizeof(RemoteState));

        timer_Clock->start(1000);

        nRemainingSec = 60;

        memcpy(stUserData.lplayerName,Local_Participant.toStdString().c_str(),Local_Participant.size());

        memcpy(stUserData.game_state, BoardDetails.toStdString().c_str(),BoardDetails.size() );

        // Push data to Lower layers
        SendMove(stUserData);

        if ( !(CalculateGameStatus(szBoardInfo.c_str()) == RESULT_RUNNING) )
        {
            QMainWindow::close();
        }

        // Disable the submit once submitted the board contents.
        ui->Button_Submit->setEnabled(false);
        timer_Regular->start(1000);

    }
}


void Game2::gui_update()
{
     tUserData stUserData;
     recv_data(stUserData);
     gui_update_board(stUserData);
}

void Game2::showTime()
{
    ui->lcdNumber->display(nRemainingSec);
    if (nRemainingSec == 0)
    {
        timer_Clock->stop();
        QString szResult;
        szResult.clear();
        if(!ui->Button_Submit->isEnabled())
        {
            szResult.append("Timer Expired - " + Local_Participant + "Won the Game -- Congrats !!!");
        }
        else
        {
            szResult.append("Timer Expired - " + Local_Participant + "Lost the Game -- Try again !!!");
        }

        update(szResult);
    }
    nRemainingSec--;

}

void Game2::setButtonState(bool bState)
{
    ui->pushButton->setEnabled(bState);      ui->pushButton_2->setEnabled(bState);
    ui->pushButton_3->setEnabled(bState);    ui->pushButton_4->setEnabled(bState);
    ui->pushButton_5->setEnabled(bState);    ui->pushButton_6->setEnabled(bState);
    ui->pushButton_7->setEnabled(bState);    ui->pushButton_8->setEnabled(bState);
    ui->pushButton_9->setEnabled(bState);
}

void Game2::getBoardInfo(string & szBoardInfo)
{
    szBoardInfo =   getButtonStatus(ui->pushButton)   + getButtonStatus(ui->pushButton_2) +
                    getButtonStatus(ui->pushButton_3) + getButtonStatus(ui->pushButton_4) +
                    getButtonStatus(ui->pushButton_5) + getButtonStatus(ui->pushButton_6) +
                    getButtonStatus(ui->pushButton_7) + getButtonStatus(ui->pushButton_8) +
                    getButtonStatus(ui->pushButton_9);

}

void Game2::on_Button_EndGame_clicked()
{
    QMessageBox msgBox;
    if (ui->Button_Submit->text() != "Submit")
    {
        msgBox.setText("Are you sure to terminate the game ?");
    }
    else
    {
        msgBox.setText("You have opted to close the game. Remember the opponent will be declared as winner if you continue to close");
        msgBox.setInformativeText("Are you sure?");
    }

    msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
    msgBox.setDefaultButton(QMessageBox::Yes);
    msgBox.exec();

    QMainWindow::close();
}

void Game2::show_pop_up(QString QMessage)
{
    QMessageBox msgBox;
    msgBox.setText(QMessage);
    msgBox.exec();
}

void Game2::gui_update_data(tUserData stUserData)
{
    QString szSymbol_l;
    QString szSymbol_r;

    szSymbol_l.clear();
    szSymbol_r.clear();

    if (stUserData.lFlag == 'O')
    {
        szSymbol_l.append("O");
        szSymbol_r.append("X");
    }
    else if (stUserData.lFlag == 'X')
    {
        szSymbol_l.append("X");
        szSymbol_r.append("O");
    }
    else
    {
        // Do nothing
    }

    ui->text_LocalSymbol->setText(szSymbol_l);
    Local_Symbol = szSymbol_l.toStdString();

    ui->text_RemoteSymbol->setText(szSymbol_r);
    Remote_Symbol = szSymbol_r.toStdString();

    if (strcmp (stUserData.rplayerName,"") && Remote_Participant.isEmpty())
    {
        Remote_Participant.append(stUserData.rplayerName);
    }

    if (Remote_Participant.isEmpty())
    {
        printf ("Empty Participant\n");
        return ;
    }

    printf ("Remote_Participant = %s\n",Remote_Participant.toStdString().c_str());
 // Remote_Participant.append(stUserData.rplayerName);
    ui->list_Participants->addItem(Remote_Participant);
    ui->Button_Submit->setEnabled(true);
    setButtonState(true);

}

void Game2::gui_update_board(tUserData stUserData)
{
    memcpy(RemoteState,stUserData.game_state,sizeof(stUserData.game_state));

    int i=0;

    isNUll(i,ui->pushButton);      i++;
    isNUll(i,ui->pushButton_2);    i++;
    isNUll(i,ui->pushButton_3);    i++;
    isNUll(i,ui->pushButton_4);    i++;
    isNUll(i,ui->pushButton_5);    i++;
    isNUll(i,ui->pushButton_6);    i++;
    isNUll(i,ui->pushButton_7);    i++;
    isNUll(i,ui->pushButton_8);    i++;
    isNUll(i,ui->pushButton_9);

    string szLocalBoardInfo;
    getBoardInfo(szLocalBoardInfo);

    int nLocalSymbol = 0;
    int nRemoteSymbol = 0;

    for (int i=0; i<szLocalBoardInfo.length();i++)
    {
        if (szLocalBoardInfo.at(i) == Local_Symbol.at(0))
        {
            nLocalSymbol++;
        }
        else if (szLocalBoardInfo.at(i) == Remote_Symbol.at(0))
        {
            nRemoteSymbol++;
        }
        else
        {
            // Do nothing.
        }
    }

    if ((nLocalSymbol < nRemoteSymbol) || ((nLocalSymbol == nRemoteSymbol) && (Local_Symbol == "O")))
    {
        ui->Button_Submit->setEnabled(true);

        //Restart the Timer with 30 Seconds.
        nRemainingSec = 60;
        timer_Clock->start(1000);

        // Stop the Regular Polling Timer when the Submit button is enabled.
        timer_Regular->stop();
    }
    else
    {
        ui->Button_Submit->setEnabled(false);
    }

    string szBoardInfo;
    getBoardInfo(szBoardInfo);

    printf("Board Info = %s\n",szBoardInfo.c_str());

    if ( !(CalculateGameStatus(szBoardInfo.c_str()) == RESULT_RUNNING) )
    {
        QMainWindow::close();
    }
}


/* Button Press Event Handlers */

void Game2::on_pushButton_clicked()
{
    Button_clicked(ui->pushButton);
}

void Game2::on_pushButton_2_clicked()
{
    Button_clicked(ui->pushButton_2);
}

void Game2::on_pushButton_3_clicked()
{
    Button_clicked(ui->pushButton_3);
}

void Game2::on_pushButton_4_clicked()
{
    Button_clicked(ui->pushButton_4);
}

void Game2::on_pushButton_5_clicked()
{
    Button_clicked(ui->pushButton_5);
}

void Game2::on_pushButton_6_clicked()
{
    Button_clicked(ui->pushButton_6);
}

void Game2::on_pushButton_7_clicked()
{
    Button_clicked(ui->pushButton_7);
}

void Game2::on_pushButton_8_clicked()
{
    Button_clicked(ui->pushButton_8);
}

void Game2::on_pushButton_9_clicked()
{
    Button_clicked(ui->pushButton_9);
}


/* Utilities */

void Game2::Button_clicked(QPushButton *pPushButton)
{
    QString QszMarked(Local_Symbol.c_str());
    pPushButton->setText(QszMarked);
    checkDuplicate();
    pPrevButtonMarked=pPushButton;
    pPushButton->setEnabled(false);
}

void Game2::isNUll(int pos, QPushButton * rPushButton)
{
    QString QszFinal;

    QszFinal.clear();

    char *szEmpty = "Z";
    if (RemoteState[pos]!=szEmpty[0])
    {
        QszFinal.append(RemoteState[pos]);
        rPushButton->setEnabled(false);
    }

    rPushButton->setText(QszFinal);
}

string Game2::getButtonStatus(QPushButton *pPushButton_temp)
{
    if (pPushButton_temp->text() == "X")
    {
        return "X";
    }
    else if (pPushButton_temp->text() == "O")
    {
        return "O";
    }
    else
    {
        return "Z";
    }
}

void Game2::checkDuplicate()
{
    if(pPrevButtonMarked != NULL)
    {
        pPrevButtonMarked->setText("");
        pPrevButtonMarked->setEnabled(true);
    }

}

void Game2::Game2_Pointer()
{
    Store_Pointer(this);
}

UINT1 Game2::CalculateGameStatus(const char *square)
{
    unsigned int ret_val = RESULT_RUNNING;

    UINT1 loop = 0;

    string Resultant_Symbol;

    if (square[0] == square[1] && square[1] == square[2] && square[2] != NOT_INTIALISED)
    {
        Resultant_Symbol.append(&square[2], 1);
        ret_val = RESULT_WON;
    }
    else if (square[3] == square[4] && square[4] == square[5] && square[5] != NOT_INTIALISED)
    {
        Resultant_Symbol.append(&square[5], 1);
        ret_val = RESULT_WON;
    }
    else if (square[6] == square[7] && square[7] == square[8] && square[8] != NOT_INTIALISED)
    {
        Resultant_Symbol.append(&square[8], 1);
        ret_val = RESULT_WON;
    }
    else if (square[0] == square[3] && square[3] == square[6] && square[6] != NOT_INTIALISED)
    {
        Resultant_Symbol.append(&square[6], 1);
        ret_val = RESULT_WON;
    }
    else if (square[1] == square[4] && square[4] == square[7] && square[7] != NOT_INTIALISED)
    {
        Resultant_Symbol.append(&square[7], 1);
        ret_val = RESULT_WON;
    }
    else if (square[2] == square[5] && square[5] == square[8] && square[8] != NOT_INTIALISED)
    {
        Resultant_Symbol.append(&square[8], 1);
        ret_val = RESULT_WON;
    }
    else if (square[0] == square[4] && square[4] == square[8] && square[8] != NOT_INTIALISED)
    {
        Resultant_Symbol.append(&square[8], 1);
        ret_val = RESULT_WON;
    }
    else if (square[2] == square[4] && square[4] == square[6] && square[6] != NOT_INTIALISED)
    {
        Resultant_Symbol.append(&square[6], 1);
        ret_val = RESULT_WON;
    }

    QString szResult;
    szResult.clear();

    for ( loop=8; loop>=0; loop-- )
    {
        if (square[loop] == NOT_INTIALISED)
        {
            break;
        }
    }

    if (loop == 0)
        ret_val = RESULT_DRAW;

    if ((ret_val == RESULT_WON) && !Resultant_Symbol.compare(Local_Symbol))
    {
        printf("sandeep %s - if  %s\n", Local_Symbol.c_str(), Resultant_Symbol.c_str());
        szResult.append(Local_Participant + " Won the Game -- Congrats !!!");
        update (szResult);
    }
    else if ((ret_val == RESULT_WON) && Resultant_Symbol.compare(Local_Symbol))
    {
        printf("sandeep %s - else if %s\n", Local_Symbol.c_str(), Resultant_Symbol.c_str());
        szResult.append(Local_Participant + " lost the Game -- Try again !!!");
        update (szResult);
    }

    return ret_val;
}
