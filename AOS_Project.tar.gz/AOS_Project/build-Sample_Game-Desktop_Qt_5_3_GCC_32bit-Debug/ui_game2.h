/********************************************************************************
** Form generated from reading UI file 'game2.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GAME2_H
#define UI_GAME2_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Game2
{
public:
    QWidget *centralWidget;
    QGroupBox *groupBox_Board;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;
    QPushButton *pushButton_9;
    QPushButton *Button_EndGame;
    QPushButton *Button_Submit;
    QGroupBox *groupBox_GameEntities;
    QTextEdit *text_RemoteSymbol;
    QLabel *label_RemoteSymbol;
    QTextEdit *text_LocalSymbol;
    QLabel *label_LocalSymbol;
    QListWidget *list_Participants;
    QLabel *label_Participants;
    QLabel *label_Header;
    QLabel *label_Caption;
    QLabel *label_LocalPlayerName;
    QGroupBox *groupBox_Credentials;
    QLabel *label_Username;
    QTextEdit *text_ServerIP;
    QLabel *label_ServerIP;
    QTextEdit *text_UserName;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;
    QToolBar *toolBar;

    void setupUi(QMainWindow *Game2)
    {
        if (Game2->objectName().isEmpty())
            Game2->setObjectName(QStringLiteral("Game2"));
        Game2->resize(580, 580);
        QSizePolicy sizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(Game2->sizePolicy().hasHeightForWidth());
        Game2->setSizePolicy(sizePolicy);
        Game2->setMaximumSize(QSize(580, 580));
        Game2->setAutoFillBackground(true);
        centralWidget = new QWidget(Game2);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        groupBox_Board = new QGroupBox(centralWidget);
        groupBox_Board->setObjectName(QStringLiteral("groupBox_Board"));
        groupBox_Board->setGeometry(QRect(40, 110, 241, 211));
        pushButton = new QPushButton(groupBox_Board);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(10, 10, 71, 61));
        QFont font;
        font.setPointSize(32);
        font.setBold(true);
        font.setWeight(75);
        pushButton->setFont(font);
        pushButton->setLayoutDirection(Qt::LeftToRight);
        pushButton_2 = new QPushButton(groupBox_Board);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(80, 10, 71, 61));
        pushButton_2->setFont(font);
        pushButton_3 = new QPushButton(groupBox_Board);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(150, 10, 71, 61));
        pushButton_3->setFont(font);
        pushButton_4 = new QPushButton(groupBox_Board);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(10, 70, 71, 61));
        pushButton_4->setFont(font);
        pushButton_5 = new QPushButton(groupBox_Board);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(80, 70, 71, 61));
        pushButton_5->setFont(font);
        pushButton_6 = new QPushButton(groupBox_Board);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(150, 70, 71, 61));
        pushButton_6->setFont(font);
        pushButton_7 = new QPushButton(groupBox_Board);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setGeometry(QRect(10, 130, 71, 61));
        pushButton_7->setFont(font);
        pushButton_8 = new QPushButton(groupBox_Board);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        pushButton_8->setGeometry(QRect(80, 130, 71, 61));
        pushButton_8->setFont(font);
        pushButton_9 = new QPushButton(groupBox_Board);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        pushButton_9->setGeometry(QRect(150, 130, 71, 61));
        pushButton_9->setFont(font);
        Button_EndGame = new QPushButton(centralWidget);
        Button_EndGame->setObjectName(QStringLiteral("Button_EndGame"));
        Button_EndGame->setGeometry(QRect(320, 420, 211, 61));
        Button_Submit = new QPushButton(centralWidget);
        Button_Submit->setObjectName(QStringLiteral("Button_Submit"));
        Button_Submit->setGeometry(QRect(50, 420, 211, 61));
        groupBox_GameEntities = new QGroupBox(centralWidget);
        groupBox_GameEntities->setObjectName(QStringLiteral("groupBox_GameEntities"));
        groupBox_GameEntities->setGeometry(QRect(320, 110, 221, 201));
        groupBox_GameEntities->setStyleSheet(QStringLiteral(""));
        text_RemoteSymbol = new QTextEdit(groupBox_GameEntities);
        text_RemoteSymbol->setObjectName(QStringLiteral("text_RemoteSymbol"));
        text_RemoteSymbol->setEnabled(false);
        text_RemoteSymbol->setGeometry(QRect(140, 80, 71, 61));
        text_RemoteSymbol->setFont(font);
        text_RemoteSymbol->setAutoFillBackground(true);
        text_RemoteSymbol->setStyleSheet(QStringLiteral("color: rgb(151, 18, 18);"));
        text_RemoteSymbol->setInputMethodHints(Qt::ImhNone);
        text_RemoteSymbol->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        text_RemoteSymbol->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        text_RemoteSymbol->setLineWrapMode(QTextEdit::WidgetWidth);
        label_RemoteSymbol = new QLabel(groupBox_GameEntities);
        label_RemoteSymbol->setObjectName(QStringLiteral("label_RemoteSymbol"));
        label_RemoteSymbol->setGeometry(QRect(140, 150, 71, 31));
        QFont font1;
        font1.setItalic(true);
        label_RemoteSymbol->setFont(font1);
        label_RemoteSymbol->setAlignment(Qt::AlignCenter);
        label_RemoteSymbol->setWordWrap(true);
        text_LocalSymbol = new QTextEdit(groupBox_GameEntities);
        text_LocalSymbol->setObjectName(QStringLiteral("text_LocalSymbol"));
        text_LocalSymbol->setEnabled(false);
        text_LocalSymbol->setGeometry(QRect(0, 80, 71, 61));
        text_LocalSymbol->setFont(font);
        text_LocalSymbol->setAutoFillBackground(true);
        text_LocalSymbol->setStyleSheet(QStringLiteral("color: rgb(151, 18, 18);"));
        text_LocalSymbol->setInputMethodHints(Qt::ImhNone);
        text_LocalSymbol->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        text_LocalSymbol->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        text_LocalSymbol->setLineWrapMode(QTextEdit::WidgetWidth);
        label_LocalSymbol = new QLabel(groupBox_GameEntities);
        label_LocalSymbol->setObjectName(QStringLiteral("label_LocalSymbol"));
        label_LocalSymbol->setGeometry(QRect(10, 150, 51, 31));
        label_LocalSymbol->setFont(font1);
        label_LocalSymbol->setAlignment(Qt::AlignCenter);
        label_LocalSymbol->setWordWrap(true);
        list_Participants = new QListWidget(groupBox_GameEntities);
        list_Participants->setObjectName(QStringLiteral("list_Participants"));
        list_Participants->setGeometry(QRect(0, 30, 211, 41));
        label_Participants = new QLabel(groupBox_GameEntities);
        label_Participants->setObjectName(QStringLiteral("label_Participants"));
        label_Participants->setGeometry(QRect(0, 0, 91, 17));
        QFont font2;
        font2.setBold(true);
        font2.setWeight(75);
        label_Participants->setFont(font2);
        label_Header = new QLabel(centralWidget);
        label_Header->setObjectName(QStringLiteral("label_Header"));
        label_Header->setGeometry(QRect(120, 10, 351, 41));
        QFont font3;
        font3.setFamily(QStringLiteral("Courier 10 Pitch"));
        font3.setPointSize(24);
        font3.setBold(true);
        font3.setWeight(75);
        label_Header->setFont(font3);
        label_Header->setStyleSheet(QStringLiteral("color:rgb(0, 0, 255);"));
        label_Header->setAlignment(Qt::AlignCenter);
        label_Caption = new QLabel(centralWidget);
        label_Caption->setObjectName(QStringLiteral("label_Caption"));
        label_Caption->setGeometry(QRect(140, 50, 311, 41));
        label_Caption->setStyleSheet(QStringLiteral("color: rgb(175, 13, 13);"));
        label_Caption->setAlignment(Qt::AlignCenter);
        label_LocalPlayerName = new QLabel(centralWidget);
        label_LocalPlayerName->setObjectName(QStringLiteral("label_LocalPlayerName"));
        label_LocalPlayerName->setGeometry(QRect(50, 340, 211, 31));
        QFont font4;
        font4.setPointSize(14);
        label_LocalPlayerName->setFont(font4);
        label_LocalPlayerName->setStyleSheet(QStringLiteral("color: rgb(146, 18, 18);"));
        label_LocalPlayerName->setAlignment(Qt::AlignCenter);
        groupBox_Credentials = new QGroupBox(centralWidget);
        groupBox_Credentials->setObjectName(QStringLiteral("groupBox_Credentials"));
        groupBox_Credentials->setGeometry(QRect(40, 349, 531, 51));
        label_Username = new QLabel(groupBox_Credentials);
        label_Username->setObjectName(QStringLiteral("label_Username"));
        label_Username->setGeometry(QRect(0, 0, 91, 31));
        label_Username->setFont(font1);
        text_ServerIP = new QTextEdit(groupBox_Credentials);
        text_ServerIP->setObjectName(QStringLiteral("text_ServerIP"));
        text_ServerIP->setGeometry(QRect(350, 0, 140, 31));
        label_ServerIP = new QLabel(groupBox_Credentials);
        label_ServerIP->setObjectName(QStringLiteral("label_ServerIP"));
        label_ServerIP->setGeometry(QRect(280, 0, 61, 31));
        label_ServerIP->setFont(font1);
        text_UserName = new QTextEdit(groupBox_Credentials);
        text_UserName->setObjectName(QStringLiteral("text_UserName"));
        text_UserName->setGeometry(QRect(89, 0, 120, 31));
        text_UserName->setInputMethodHints(Qt::ImhNone);
        text_UserName->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        text_UserName->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        text_UserName->setTabChangesFocus(true);
        text_UserName->setUndoRedoEnabled(false);
        text_UserName->setTabStopWidth(80);
        Game2->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(Game2);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 580, 25));
        Game2->setMenuBar(menuBar);
        mainToolBar = new QToolBar(Game2);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        Game2->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(Game2);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        Game2->setStatusBar(statusBar);
        toolBar = new QToolBar(Game2);
        toolBar->setObjectName(QStringLiteral("toolBar"));
        Game2->addToolBar(Qt::TopToolBarArea, toolBar);

        retranslateUi(Game2);

        QMetaObject::connectSlotsByName(Game2);
    } // setupUi

    void retranslateUi(QMainWindow *Game2)
    {
        Game2->setWindowTitle(QApplication::translate("Game2", "TicTacToe", 0));
        groupBox_Board->setTitle(QString());
        pushButton->setText(QString());
        pushButton_2->setText(QString());
        pushButton_3->setText(QString());
        pushButton_4->setText(QString());
        pushButton_5->setText(QString());
        pushButton_6->setText(QString());
        pushButton_7->setText(QString());
        pushButton_8->setText(QString());
        pushButton_9->setText(QString());
        Button_EndGame->setText(QApplication::translate("Game2", "End Game", 0));
        Button_Submit->setText(QApplication::translate("Game2", "Start", 0));
        groupBox_GameEntities->setTitle(QString());
        label_RemoteSymbol->setText(QApplication::translate("Game2", "Opponent Symbol", 0));
        label_LocalSymbol->setText(QApplication::translate("Game2", "Your Symbol", 0));
        label_Participants->setText(QApplication::translate("Game2", "Participants", 0));
        label_Header->setText(QApplication::translate("Game2", "TicTacToe Network", 0));
        label_Caption->setText(QApplication::translate("Game2", "A LAN Based Game using AOS Concepts", 0));
        label_LocalPlayerName->setText(QString());
        groupBox_Credentials->setTitle(QString());
        label_Username->setText(QApplication::translate("Game2", "Player Name", 0));
        label_ServerIP->setText(QApplication::translate("Game2", "Server IP", 0));
        toolBar->setWindowTitle(QApplication::translate("Game2", "toolBar", 0));
    } // retranslateUi

};

namespace Ui {
    class Game2: public Ui_Game2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GAME2_H
