/****************************************************************************
** Meta object code from reading C++ file 'game2.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../Sample_Game/game2.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'game2.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_Game2_t {
    QByteArrayData data[36];
    char stringdata[533];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Game2_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Game2_t qt_meta_stringdata_Game2 = {
    {
QT_MOC_LITERAL(0, 0, 5),
QT_MOC_LITERAL(1, 6, 24),
QT_MOC_LITERAL(2, 31, 0),
QT_MOC_LITERAL(3, 32, 25),
QT_MOC_LITERAL(4, 58, 6),
QT_MOC_LITERAL(5, 65, 8),
QT_MOC_LITERAL(6, 74, 12),
QT_MOC_LITERAL(7, 87, 15),
QT_MOC_LITERAL(8, 103, 6),
QT_MOC_LITERAL(9, 110, 12),
QT_MOC_LITERAL(10, 123, 16),
QT_MOC_LITERAL(11, 140, 12),
QT_MOC_LITERAL(12, 153, 7),
QT_MOC_LITERAL(13, 161, 11),
QT_MOC_LITERAL(14, 173, 21),
QT_MOC_LITERAL(15, 195, 23),
QT_MOC_LITERAL(16, 219, 23),
QT_MOC_LITERAL(17, 243, 23),
QT_MOC_LITERAL(18, 267, 23),
QT_MOC_LITERAL(19, 291, 23),
QT_MOC_LITERAL(20, 315, 23),
QT_MOC_LITERAL(21, 339, 23),
QT_MOC_LITERAL(22, 363, 23),
QT_MOC_LITERAL(23, 387, 14),
QT_MOC_LITERAL(24, 402, 11),
QT_MOC_LITERAL(25, 414, 14),
QT_MOC_LITERAL(26, 429, 6),
QT_MOC_LITERAL(27, 436, 3),
QT_MOC_LITERAL(28, 440, 11),
QT_MOC_LITERAL(29, 452, 14),
QT_MOC_LITERAL(30, 467, 6),
QT_MOC_LITERAL(31, 474, 8),
QT_MOC_LITERAL(32, 483, 10),
QT_MOC_LITERAL(33, 494, 19),
QT_MOC_LITERAL(34, 514, 11),
QT_MOC_LITERAL(35, 526, 6)
    },
    "Game2\0on_Button_Submit_clicked\0\0"
    "on_Button_EndGame_clicked\0update\0"
    "szResult\0Registration\0getButtonStatus\0"
    "string\0QPushButton*\0pPushButton_temp\0"
    "getBoardInfo\0string&\0szBoardInfo\0"
    "on_pushButton_clicked\0on_pushButton_2_clicked\0"
    "on_pushButton_3_clicked\0on_pushButton_4_clicked\0"
    "on_pushButton_5_clicked\0on_pushButton_6_clicked\0"
    "on_pushButton_7_clicked\0on_pushButton_8_clicked\0"
    "on_pushButton_9_clicked\0Button_clicked\0"
    "pPushButton\0checkDuplicate\0isNUll\0pos\0"
    "rPushButton\0setButtonState\0bState\0"
    "showTime\0gui_update\0CalculateGameStatus\0"
    "const char*\0square"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Game2[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      22,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  124,    2, 0x08 /* Private */,
       3,    0,  125,    2, 0x08 /* Private */,
       4,    1,  126,    2, 0x08 /* Private */,
       6,    0,  129,    2, 0x08 /* Private */,
       7,    1,  130,    2, 0x08 /* Private */,
      11,    1,  133,    2, 0x08 /* Private */,
      14,    0,  136,    2, 0x08 /* Private */,
      15,    0,  137,    2, 0x08 /* Private */,
      16,    0,  138,    2, 0x08 /* Private */,
      17,    0,  139,    2, 0x08 /* Private */,
      18,    0,  140,    2, 0x08 /* Private */,
      19,    0,  141,    2, 0x08 /* Private */,
      20,    0,  142,    2, 0x08 /* Private */,
      21,    0,  143,    2, 0x08 /* Private */,
      22,    0,  144,    2, 0x08 /* Private */,
      23,    1,  145,    2, 0x08 /* Private */,
      25,    0,  148,    2, 0x08 /* Private */,
      26,    2,  149,    2, 0x08 /* Private */,
      29,    1,  154,    2, 0x08 /* Private */,
      31,    0,  157,    2, 0x08 /* Private */,
      32,    0,  158,    2, 0x08 /* Private */,
      33,    1,  159,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Bool,
    0x80000000 | 8, 0x80000000 | 9,   10,
    QMetaType::Void, 0x80000000 | 12,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 9,   24,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 9,   27,   28,
    QMetaType::Void, QMetaType::Bool,   30,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::UChar, 0x80000000 | 34,   35,

       0        // eod
};

void Game2::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Game2 *_t = static_cast<Game2 *>(_o);
        switch (_id) {
        case 0: _t->on_Button_Submit_clicked(); break;
        case 1: _t->on_Button_EndGame_clicked(); break;
        case 2: _t->update((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 3: { bool _r = _t->Registration();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 4: { string _r = _t->getButtonStatus((*reinterpret_cast< QPushButton*(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< string*>(_a[0]) = _r; }  break;
        case 5: _t->getBoardInfo((*reinterpret_cast< string(*)>(_a[1]))); break;
        case 6: _t->on_pushButton_clicked(); break;
        case 7: _t->on_pushButton_2_clicked(); break;
        case 8: _t->on_pushButton_3_clicked(); break;
        case 9: _t->on_pushButton_4_clicked(); break;
        case 10: _t->on_pushButton_5_clicked(); break;
        case 11: _t->on_pushButton_6_clicked(); break;
        case 12: _t->on_pushButton_7_clicked(); break;
        case 13: _t->on_pushButton_8_clicked(); break;
        case 14: _t->on_pushButton_9_clicked(); break;
        case 15: _t->Button_clicked((*reinterpret_cast< QPushButton*(*)>(_a[1]))); break;
        case 16: _t->checkDuplicate(); break;
        case 17: _t->isNUll((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QPushButton*(*)>(_a[2]))); break;
        case 18: _t->setButtonState((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 19: _t->showTime(); break;
        case 20: _t->gui_update(); break;
        case 21: { unsigned char _r = _t->CalculateGameStatus((*reinterpret_cast< const char*(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< unsigned char*>(_a[0]) = _r; }  break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QPushButton* >(); break;
            }
            break;
        case 15:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QPushButton* >(); break;
            }
            break;
        case 17:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QPushButton* >(); break;
            }
            break;
        }
    }
}

const QMetaObject Game2::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_Game2.data,
      qt_meta_data_Game2,  qt_static_metacall, 0, 0}
};


const QMetaObject *Game2::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Game2::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Game2.stringdata))
        return static_cast<void*>(const_cast< Game2*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int Game2::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
